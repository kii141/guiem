# will-you-be-my-valentine

Demo : https://saurabhnemade.github.io/will-you-be-my-valentine/

This is a fun project for valentines day to bring smile on face of your special person!!

This project is inspired from
https://gist.github.com/tnarla/0c09a11fea366145ba684fe6ebf578c5 & https://www.tiktok.com/@mewtru/video/7331131143112166698

# How to start
```
npm install -g pnpm
pnpm i
pnpm run dev
```

# Preview

![image description](demo.gif)


# How to deploy it
```
pnpm run deploy
```

Made with love in Berlin!❤️
